module.exports = {
  BOT_NAME: 'Formation',
  OWNER_NAME: 'Dracula Tech',
  OWNER_NUMBER: '50956461555',
  SESSION_DIR: './baileys',
  NO_PREFIX: true,
  STATUS_VIEW: true
};





